# -*- coding: utf-8 -*-
"""
Created on Sun Nov 20 02:01:19 2022

@author: ryani
"""
import json
from Bear import bear
from BerryField import berry
from Tourist import tourist

if __name__=='__main__':
    jsonn=input('Enter the json file name for the simulation => ').strip()
    print(jsonn)
    print('\n', end='')
    file = open (jsonn)
    # file = open("bears_and_berries_1.json")
    data = json.loads(file.read())
    berry_field=berry(data['berry_field'], data['active_bears'], \
                data['active_tourists'])
    berry_field_sum=berry.total(berry_field)
    berry_field_bt=berry.bt(berry_field)    
    print('Field has {} berries.'.format(berry_field_sum))
    print(berry(berry_field_bt, data['active_bears'], \
                 data['active_tourists']))
    print('Active Bears:')
    for bears in data['active_bears']:
        print(bear(bears))
    print('\nActive Tourists:')
    for tourists in data['active_tourists']:
        print(tourist(tourists, data['reserve_tourists']))
    
    
    