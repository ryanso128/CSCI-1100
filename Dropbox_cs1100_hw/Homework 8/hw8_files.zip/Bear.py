# -*- coding: utf-8 -*-
"""
Created on Thu Dec  8 16:10:18 2022

@author: ryani
"""

class bear(object):
    def __init__(self, x, y, direction):
        self.x=x
        self.y=y
        self.direction=direction
        self.sleep=False
        self.sleep_turns=0
        self.stop=False
    
    def __str__(self):
        if self.sleep!=False:
            return 'Bear at ({},{}) moving {} - Asleep for {} more turns'\
                .format(self.x, self.y, self.direction, self.sleep_turns)
        return 'Bear at ({},{}) moving {}'.format(self.x, self.y, self.direction)
    
    def moving(self):
        direction=self.direction
        if 'N' in direction:
            self.x-=1
        if 'W' in direction:
            self.y-=1
        if 'S' in direction:
            self.x+=1
        if 'E' in direction:
            self.y+=1