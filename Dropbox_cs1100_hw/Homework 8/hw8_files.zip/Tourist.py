# -*- coding: utf-8 -*-
"""
Created on Thu Dec  8 16:10:18 2022

@author: ryani
"""
class tourist(object):
    
    def __init__(self, x, y):
        self.x=x
        self.y=y
        self.left=False
        self.bear_watch=0
    
    def __str__(self):
        return 'Tourist at ({},{}), {} turns without seeing a bear'\
            .format(self.x, self.y, self.bear_watch)

if __name__=='__main__':
    touristss=[(0,9), (4,5)]
    bear=0
    field=0
    for tourists in touristss:
        tourists=tourist(field, bear, tourists)
        print(tourists)
