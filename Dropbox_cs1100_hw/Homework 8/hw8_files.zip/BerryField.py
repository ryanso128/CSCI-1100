# -*- coding: utf-8 -*-
"""
Created on Thu Dec  8 16:10:17 2022

@author: ryani
"""
from Bear import bear
from Tourist import tourist
class berry(object):
    
    def __init__(self, field, bears, tourists):
        self.field=field
        self.bears=bears
        self.tourists=tourists
        
    def __str__(self):
        grid=''
        for rows in range(len(self.field)):
            for columns in range(len(self.field[0])):
                x=''
                for bears in self.bears:
                    if bears.x==rows and bears.y==columns:
                        x='B'
                for tourists in self.tourists:
                    if tourists.x==rows and tourists.y==columns:
                        if x=='B':
                            x='X'
                        else:
                            x='T'
                if x!='':
                    grid+='{: >4}'.format(x)
                else:
                    grid+='{: >4}'.format(self.field[rows][columns])
            grid+='\n'
        return grid
    
    def growing(self):
        for rows in range(len(self.field)):
            for columns in range(len(self.field[0])):
                if 0<self.field[rows][columns]<10:
                    self.field[rows][columns]+=1
        for rows in range(len(self.field)):
            for columns in range(len(self.field[0])):
                if self.field[rows][columns]==0 and 0<=rows-1<=len(self.field)-1:
                    if self.field[rows-1][columns]==10:
                        self.field[rows][columns]+=1
                if self.field[rows][columns]==0 and 0<=columns+1<=len(self.field[0])-1:
                    if self.field[rows][columns+1]==10:
                        self.field[rows][columns]+=1
                if self.field[rows][columns]==0 and 0<=rows+1<=len(self.field)-1:
                    if self.field[rows+1][columns]==10:
                        self.field[rows][columns]+=1
                if self.field[rows][columns]==0 and 0<=columns-1<=len(self.field[0])-1:
                    if self.field[rows][columns-1]==10:
                        self.field[rows][columns]+=1
                if self.field[rows][columns]==0 and 0<=rows-1<=len(self.field)-1 and 0<=columns-1<=len(self.field[0])-1:
                    if self.field[rows-1][columns-1]==10:
                        self.field[rows][columns]+=1
                if self.field[rows][columns]==0 and 0<=rows-1<=len(self.field)-1 and 0<=columns+1<=len(self.field[0])-1:
                    if self.field[rows-1][columns+1]==10:
                        self.field[rows][columns]+=1
                if self.field[rows][columns]==0 and 0<=rows+1<=len(self.field)-1 and 0<=columns+1<=len(self.field[0])-1:
                    if self.field[rows+1][columns+1]==10:
                        self.field[rows][columns]+=1
                if self.field[rows][columns]==0 and 0<=rows+1<=len(self.field)-1 and 0<=columns-1<=len(self.field[0])-1:
                    if self.field[rows+1][columns-1]==10:
                        self.field[rows][columns]+=1
    
    def count(self):
        total=0
        for rows in self.field:
            total+=sum(rows)
        return total